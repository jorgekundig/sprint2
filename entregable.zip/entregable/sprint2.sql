-- Sprint 2
/*
Nivel 1:
Ex. 1
A partir de los documentos adjuntos (estructura_dades y dades_introduir), importa las dos tablas. 
Muestra las características principales del esquema creado y explica las diferentes tablas y variables que existen. 
Asegúrate de incluir un diagrama que ilustre la relación entre las diferentes tablas y variables.

R: La base de datos 'transactions' incluye 2 tablas: company (tabla madre) y transaction (tabla hija), con relación 1n a través del id de company.
La tabla company incluye las siguientes columnas: 
- id: PK, con valores tipo string (b-2222, b-2618) no continuos
- company_name: el nombre de cada empresa (string)
- phone: el número telefónico de cada empresa (string)
- email: el correo electrónico de cada empresa (string)
- country: el país de origen de cada empresa (string), se repiten
- website: el sitio web de cada empresa (string)
La tabla transaction incluye las siguientes columnas:
- id: PK, con valores alfanuméricos (string): 02C6201E-D90A-1859-B4EE-88D2986D3B02, 0466A42E-47CF-8D24-FD01-C0B689713128, etc
- credit_card_id: también con valores alfanuméricos (string) no consecutivos: CcU-2938, CcU-4219, etc
- company_id: valor tipo string, FK (PK de la tabla company)
- user_id: valores numéricos (int) repetidos (un mismo usuario puede haber hecho más de una transacción)
- lat: valores numéricos decimales (float) de latitud
- longitude: valores numéricos decimales (float) de longitud
- timestamp: valores tipo timestamp (fecha y hora de cada transacción)
- amount: valor numérico decimal (decimal 10,2), el monto de cada transacción
- declined: valores 0 y 1 (tinyint(1)), 1 para las transacciones rechazadas y 0 para transacciones completadas.
*/

USE transactions;

/*
Ex. 2
Utilizando JOIN realizarás las siguientes consultas:
- Listado de los países que están generando ventas.
- Desde cuántos países se generan las ventas.
- Identifica la compañía con la media más grande de ventas.
*/
-- Listado de países:
SELECT DISTINCT country
FROM company c
JOIN transaction t ON c.id = t.company_id
WHERE declined = 0 AND c.country IS NOT NULL;

-- Cantidad de países desde los que se hacen las compras:
SELECT COUNT(DISTINCT country) AS total_paises
FROM company c
JOIN transaction t ON c.id = t.company_id
WHERE declined = 0;

-- Compañía con la media de ventas más grande:
SELECT c.company_name, ROUND(AVG(t.amount),2) AS media_ventas
FROM company c
JOIN transaction t ON c.id = t.company_id
WHERE t.declined = 0
GROUP BY c.company_name
ORDER BY media_ventas DESC
LIMIT 1;


/*
Ex. 3
Utilizando nada más subconsultas (sin utilizar JOIN):
- Muestra todas las transacciones realizadas por empresas de Alemania.
- Enlista las empresas que han realizado transacciones por un monto superior a la media de todas las transacciones.
- Elimina del sistema las empresas que no tienen transacciones registradas, entrega el listado de estas empresas.
*/
-- Transacciones de empresas de Alemania
SELECT *
FROM transaction t
WHERE t.company_id IN (
	SELECT c.id
	FROM company c
	WHERE c.country = 'Germany');


-- Empresas con transacciones por montos superiores a la media de todas
-- revisar por qué no da el segundo, en general revisar bien este ejercicio

SELECT id, company_name
FROM company c
WHERE EXISTS (
	SELECT 1
    FROM transaction t
    WHERE t.company_id = c.id AND declined = 0 AND t.amount > (
		SELECT AVG(t.amount)
        FROM transaction t
        )
	);

SELECT (
	SELECT c.company_name
    FROM company c
	WHERE c.id = t.company_id) AS nombre_empresa, t.company_id, t.amount, (
		SELECT AVG(t2.amount)
		FROM transaction t2) AS media_general
FROM transaction t
GROUP BY t.company_id, t.amount
HAVING AVG(t.amount) > (
	SELECT AVG(t2.amount)
	FROM transaction t2)
ORDER BY t.amount;

-- Lista de empresas sin transacciones registradas
-- El resultado da 0, interpreto que todas las empresas tienen al menos una transacción válida
SELECT c.id, c.company_name
FROM company c
WHERE c.id NOT IN (
    SELECT t.company_id
	FROM transaction t
	WHERE c.id IS NOT NULL
);

/*
Ex. 4
Tu tarea es diseñar y crear una tabla denominada "credit_card" que almacene detalles cruciales sobre las tarjetas de crédito. 
La nueva tabla ha de ser capaz de identificar de manera única cada tarjeta y establecer una relación adecuada con las otras dos tablas 
("transaction" y "company"). Después de crear la tabla será necesario que ingreses la información del documento denominado “dades_introduir_credit". 
Recuerda mostrar el diagrama y realizar una breve descripción de este.
*/

-- Después de examinar las columnas a agregar en el documento dades_introduir_credit y el tipo de datos que contienen, creamos la tabla credit_card
CREATE TABLE IF NOT EXISTS credit_card (
id VARCHAR(15) PRIMARY KEY, 
iban VARCHAR(34),
pan VARCHAR(20),
pin CHAR(4),
cvv CHAR(3),
expiring_date VARCHAR(20)); -- En principio esta columna se crea como string, ya que los datos que introduciremos vienen en ese formato

-- Aquí se ejecuta el código del documento dades_introduir_credit.sql para introducir los datos y llenar la tabla credit_card, lo comprobamos:
SELECT *
FROM credit_card;


-- Convertir la columna expiring_date a formato DATE
UPDATE credit_card
SET expiring_date = STR_TO_DATE(expiring_date, '%m/%d/%y');

ALTER TABLE credit_card
MODIFY COLUMN expiring_date DATE;

-- Después modificamos la relación entre transaction y credit_card, para que la PK id de credit_card sea una FK en transaction (relación 1n)
ALTER TABLE transaction 
ADD CONSTRAINT fk_card_id 
FOREIGN KEY (credit_card_id) 
REFERENCES credit_card(id);

/*
Ex. 5
El departamento de Recursos Humanos ha identificado un error en el número de cuenta asociado a la tarjeta de crédito con ID CcU-2938. 
La información que ha de mostrarse para este registro es: TR323456312213576817699999. Recuerda mostrar que el cambio se realizó.
*/

UPDATE credit_card
SET iban = 'TR323456312213576817699999'
WHERE id = 'CcU-2938';

SELECT *
FROM credit_card
WHERE id = 'CcU-2938';

/*
Ex. 6
En la tabla "transaction" ingresa una nueva transacción con la siguiente información:
- id: 108B1D1D-5B23-A76C-55EF-C568E49A99DD 
- credit_card_id : CcU-9999 
- company_id: b-9999 
- user_id: 9999 
- lat: 829.999 
- longitude: -117.999 
- amount: 111.11 
- declined: 0
*/

-- Al tener en transaction 2 FKs (credit_card_id y company_id), debemos antes ingresar esos valores en sus respectivas tablas madre 
-- (credit_card y company), aunque el resto de la fila quede en NULL.

INSERT INTO credit_card (id)
VALUES ('CcU-9999');

INSERT INTO company (id)
VALUES ('b-9999');

-- Insertamos los datos 
INSERT INTO transaction (id, credit_card_id, company_id, user_id, lat, longitude, amount, declined)
VALUES
('108B1D1D-5B23-A76C-55EF-C568E49A99DD', 'CcU-9999', 'b-9999', 9999, 829.999, -117.999, 111.11, 0);


-- Falta el dato del timestamp, no indicado en el enunciado. Lo añadí después, utilizando CURRENT_TIMESTAMP para indicar la fecha y hora
UPDATE transaction
SET timestamp = CURRENT_TIMESTAMP()
WHERE company_id = 'b-9999';

-- Comprobación de que la fila se llenó
SELECT *
FROM transaction
WHERE credit_card_id = 'CcU-9999' AND company_id = 'b-9999';

/*
Ex. 7
Desde recursos humanos te solicitan eliminar la columna "pan" de la tabla credit_card. Recuerda mostrar el cambio realizado.
*/

ALTER TABLE credit_card 
DROP pan;

SELECT *
FROM credit_card;

/*
Ex. 8
Descarga los archivos CSV que encontrarás en el apartado de recursos:
- american_users.csv
- european_users.csv
- companies.csv
- credit_cards.csv
- transactions.csv
Estúdialos y diseña una base de datos con un esquema de estrella que contenga, al menos 4 tablas de las cuales puedas realizar las 
siguientes consultas:
*/

-- Crear base de datos nueva
CREATE DATABASE operations;
USE operations;

-- Crear tablas a llenar (estamos haciendo una sola tabla de usuarios, donde descargaremos los datos de los ficheros 
-- american_users.csv y european_users.csv añadiendo su región en una nueva columna)
CREATE TABLE companies (
company_id VARCHAR(15) PRIMARY KEY,
company_name VARCHAR(50),
phone VARCHAR(50),
email VARCHAR(200),
country VARCHAR(50),
website VARCHAR(200));

CREATE TABLE credit_cards (
id VARCHAR(15) PRIMARY KEY,
user_id VARCHAR(50),
iban VARCHAR(50),
pan VARCHAR(50),
pin CHAR(4),
cvv CHAR(3),
track1 VARCHAR(200),
track2 VARCHAR(200),
expiring_date VARCHAR(20));

CREATE TABLE users (
id VARCHAR(15) PRIMARY KEY,
name VARCHAR(50),
surname VARCHAR(50),
phone VARCHAR(50),
email VARCHAR(200),
birth_date VARCHAR(50),
country VARCHAR(50),
city VARCHAR(50),
postal_code VARCHAR(15),
address VARCHAR(200),
region VARCHAR(50));


-- Llenar las tablas con los datos de los ficheros csv
LOAD DATA LOCAL INFILE '/Users/jkundig/Documents/IT Academy/especialización/sprint2/companies.csv'
INTO TABLE companies
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA LOCAL INFILE '/Users/jkundig/Documents/IT Academy/especialización/sprint2/credit_cards.csv'
INTO TABLE credit_cards
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA LOCAL INFILE '/Users/jkundig/Documents/IT Academy/especialización/sprint2/american_users.csv'
INTO TABLE users
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
SET region = 'America';

LOAD DATA LOCAL INFILE '/Users/jkundig/Documents/IT Academy/especialización/sprint2/european_users.csv'
INTO TABLE users
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
SET region = 'Europe';

SELECT *
FROM users;

-- Esta tabla de hechos se hace hasta el final, para añadir los FK una vez que se han llenado los datos de las otras tablas
CREATE TABLE transactions (
id VARCHAR(50) PRIMARY KEY,
card_id VARCHAR(15),
business_id VARCHAR(15),
timestamp TIMESTAMP,
amount DECIMAL (10,2),
declined TINYINT,
product_ids VARCHAR(50),
user_id VARCHAR(15),
lat FLOAT,
longitude FLOAT,
CONSTRAINT fk_trans_card_id FOREIGN KEY (card_id) REFERENCES credit_cards(id),
CONSTRAINT fk_trans_company_id FOREIGN KEY (business_id) REFERENCES companies(company_id),
CONSTRAINT fk_trans_user_id FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

LOAD DATA LOCAL INFILE '/Users/jkundig/Documents/IT Academy/especialización/sprint2/transactions.csv'
INTO TABLE transactions
FIELDS TERMINATED BY ';'
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

SELECT *
FROM transactions;

/*
Ex. 9
Realiza una subconsulta que muestre todos los usuarios con más de 80 transacciones utilizando al menos 2 tablas.
*/

SELECT u.id, u.name, u.surname, COUNT(t.id) AS total_transacciones
FROM users u
JOIN transactions t ON u.id = t.user_id
WHERE u.id IN (
	SELECT t.user_id
	FROM transactions t
	GROUP BY t.user_id
	HAVING COUNT(*) > 80)
GROUP BY u.id, u.name, u.surname
ORDER BY total_transacciones DESC;

/*
Ex. 10
Muestra la media de monto por IBAN de las tarjetas de crédito en la compañíia Donec Ltd, utiliza al menos 2 tablas.
*/

SELECT cc.iban, c.company_name, ROUND(AVG(t.amount),2) AS avg_amount
FROM companies c
JOIN transactions t ON c.company_id = t.business_id
JOIN credit_cards cc ON cc.id = t.card_id
WHERE c.company_name = 'Donec Ltd'
GROUP BY cc.iban, c.company_name;


/*
Nivel 2:
Ex. 1
Identifica los cinco días que se generó la cantidad más grande de ingresos en la empresa por ventas. Muestra la fecha de cada transacción 
junto con el total de las ventas.
*/
SELECT DATE(timestamp) AS fecha, ROUND(SUM(amount),2) as monto
FROM transactions
GROUP BY fecha
ORDER BY monto DESC
LIMIT 5;

/*
Ex. 2
Presenta el nombre, teléfono, país, fecha y monto, de aquellas empresas que realizaron transacciones con un valor comprendido entre 
350 y 400 euros y en alguna de estas fechas: 29 de abril del 2015, 20 de julio del 2018 y 13 de marzo del 2024. 
Ordena los resultados de mayor a menor cantidad.
*/
SELECT c.company_name, c.phone, c.country, ROUND(t.amount,2) AS amount, DATE(t.timestamp) AS fecha_transaccion
FROM companies c
JOIN transactions t on c.company_id = t.business_id
WHERE t.amount BETWEEN 350 AND 400 AND DATE(t.timestamp) IN ('2015-04-29', '2018-07-20', '2024-03-13')
ORDER BY t.amount DESC;


/*
Ex. 3
Necesitamos optimizar la asignación de los recursos y dependerá de la capacidad operativa que se requiera, por lo que te piden la información 
sobre la cantidad de transacciones que realicen las empresas, pero el departamento de recursos humanos es exigente y quiere un listado de 
las empresas donde especifiques si tienen más de 400 transacciones o menos.
*/

SELECT 
    t.business_id,
    c.company_name,
    COUNT(*) AS num_transacciones,
    CASE 
        WHEN COUNT(*) > 400 THEN 'mas_400'
        WHEN COUNT(*) < 400 THEN 'menos_400'
    END AS grupo
FROM transactions t
JOIN companies c ON t.business_id = c.company_id
GROUP BY t.business_id;

/*
Solución con UNION
SELECT business_id, COUNT(*) AS num_transacciones, 'mas_400' AS grupo
FROM transactions
GROUP BY business_id
HAVING num_transacciones > 400 
UNION 
SELECT business_id, COUNT(*) AS num_transacciones, 'menos_400' AS grupo
FROM transactions
GROUP BY business_id
HAVING num_transacciones < 400;
*/

/*
Ex. 4
Elimina de la tabla transactions el registro con ID 000447FE-B650-4DCF-85DE-C7ED0EE1CAAD de la base de datos.
*/

DELETE FROM transactions
WHERE id = '000447FE-B650-4DCF-85DE-C7ED0EE1CAAD';

SELECT *
FROM transactions
WHERE id = '000447FE-B650-4DCF-85DE-C7ED0EE1CAAD';

/*
Ex. 5
La sección de marketing desea tener acceso a información específica para realizar análisis y estrategias efectivas. 
Se ha solicitado crear una vista que proporcione detalles clave sobre las compañías y sus transacciones. 
Será necesario que crees una vista denominada VistaMarketing que contenga la siguiente información: 
- Nombre de la compañía. 
- Teléfono de contacto. 
- País de residencia. 
- Media de compra realizada por cada compañía. 
Presenta la vista creada, ordenando los datos de mayor a menor media de compra.
*/

CREATE VIEW VistaMarketing AS
SELECT c.company_name, c.phone, c.country, ROUND(AVG(t.amount),2) AS avg_amount
FROM companies c
JOIN transactions t ON c.company_id = t.business_id
WHERE t.declined = 0
GROUP BY c.company_name, c.phone, c.country
ORDER BY avg_amount DESC;

SELECT *
FROM VistaMarketing;

/*
Nivell 3:
Ex. 1
Crea una nueva tabla que refleje el estado de las tarjetas de crédito basado en si las tres últimas transacciones han sido declinadas 
entonces es inactivo, si al menos una no es rechazada entonces es activo. Partiendo de esta tabla responde:
- ¿Cuántas tarjetas están activas?
*/

CREATE TABLE card_status AS
SELECT 
	card_id, 
    CASE
        WHEN SUM(declined) = 3 THEN 'inactivo'
        ELSE 'activo'
    END AS estado
FROM (
    SELECT card_id, declined, ROW_NUMBER() OVER (PARTITION BY card_id ORDER BY timestamp DESC) AS rn
    FROM transactions
) AS subq_rn
WHERE rn <= 3
GROUP BY card_id;

SELECT COUNT(*)
FROM card_status
WHERE estado = 'activo';

/*
Ex. 2
Crea una tabla con la que podamos unir los datos del nuevo archivo products.csv con la base de datos creada, teniendo en cuenta que desde 
transaction tienes product_ids. Genera la siguiente consulta:
- Necesitamos conocer el número de veces que se ha vendido cada producto.
*/

-- Crear tabla products
CREATE TABLE products (
id VARCHAR(15) PRIMARY KEY,
product_name VARCHAR(50),
price VARCHAR(50),
colour VARCHAR(50),
weight DECIMAL(10,2),
warehouse_id VARCHAR(50));

-- Importar datos de products.csv
LOAD DATA LOCAL INFILE '/Users/jkundig/Documents/IT Academy/especialización/sprint2/products.csv'
INTO TABLE products
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

-- Desglosar los valores de la columna product_ids en varias filas con JSON_TABLE y CONCAT (convierte el valor en un array JSON) y 
-- calcular las veces que se ha vendido cada producto.
SELECT p.product_name, COUNT(*) AS total_vendidos
FROM transactions t
JOIN JSON_TABLE (
    CONCAT('[', t.product_ids, ']'), '$[*]'
    COLUMNS (product_id INT PATH '$')
) AS jt
JOIN products p ON jt.product_id = p.id
GROUP BY p.product_name
ORDER BY total_vendidos DESC;

-- Crear tabla puente transactions_products
CREATE TABLE transactions_products (
	transaction_id VARCHAR(50),
    product_id VARCHAR(40),
	PRIMARY KEY (transaction_id, product_id),
    FOREIGN KEY (transaction_id) REFERENCES transactions(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Llenar la tabla puente usando de nuevo JSON_TABLE
INSERT INTO transactions_products (transaction_id, product_id)
SELECT t.id, tt.product_id
FROM transactions t
JOIN JSON_TABLE(
    CONCAT('[', t.product_ids, ']'),
    '$[*]'
    COLUMNS (product_id VARCHAR(15) PATH '$')
) AS tt;
